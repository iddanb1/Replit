## Packages
date-fns | Date formatting and manipulation
framer-motion | Smooth animations and page transitions

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
